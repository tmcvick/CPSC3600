/* Daniel Branum
   dbranum
   CPSC 360
   HW2
*/

Files included in archive:

-webserver.c
-getfile.c
-functions.c
-Makefile
-README

DESIGN:

The object of this project was to design a simple http server and client. 
The client would send either a GET or HEAD request and the server would process
the request and return an appropriate http response based on the request. The folowing
resonses were possible:

200 OK - This signifes that everything went ok and that the request was processed successfully
400 Bad Request - This means the http request was malformed
403 Forbidden - This means the file requested was either not in the current directory or that
				the client does not have permission to access the file
404 Error - File not found - This means the file requested could not be located
405 Error : Unsupported Request - This means the client's request is unsupported (not GET or HEAD)

My design uses string functions to parse the request from the client and then concatenates the required
pieces of the response creating the appropriate response header that the server can provide to the
client.

In order to modulize my program I have included a source file known as functions.c that includes
fucntions written to simplify my server and client files.


KNOWN PROBLEMS:

Other than checking for the appropriate errors listed above my program does not have extensive error
handling capabilities. For instance, if provided with incorrect command-line parameters the program will most likely
crash.
